package stu;

public class Stu {

	private int stuID;
	private String stuTitle;
	private String userID;
	private String stuDate;
	private String stuContent;
	private int stuAvailable;
	
	public int getStuID() {
		return stuID;
	}
	public void setStuID(int stuID) {
		this.stuID = stuID;
	}
	public String getStuTitle() {
		return stuTitle;
	}
	public void setStuTitle(String stuTitle) {
		this.stuTitle = stuTitle;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getStuDate() {
		return stuDate;
	}
	public void setStuDate(String stuDate) {
		this.stuDate = stuDate;
	}
	public String getStuContent() {
		return stuContent;
	}
	public void setStuContent(String stuContent) {
		this.stuContent = stuContent;
	}
	public int getStuAvailable() {
		return stuAvailable;
	}
	public void setStuAvailable(int stuAvailable) {
		this.stuAvailable = stuAvailable;
	}
}
