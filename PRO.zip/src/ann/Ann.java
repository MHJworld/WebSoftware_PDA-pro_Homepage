package ann;

public class Ann {

	private int annID;
	private String annTitle;
	private String userID;
	private String annDate;
	private String annContent;
	private int annAvailable;
	
	public int getAnnID() {
		return annID;
	}
	public void setAnnID(int annID) {
		this.annID = annID;
	}
	public String getAnnTitle() {
		return annTitle;
	}
	public void setAnnTitle(String annTitle) {
		this.annTitle = annTitle;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}
	public String getAnnDate() {
		return annDate;
	}
	public void setAnnDate(String annDate) {
		this.annDate = annDate;
	}
	public String getAnnContent() {
		return annContent;
	}
	public void setAnnContent(String annContent) {
		this.annContent = annContent;
	}
	public int getAnnAvailable() {
		return annAvailable;
	}
	public void setAnnAvailable(int annAvailable) {
		this.annAvailable = annAvailable;
	}
}
